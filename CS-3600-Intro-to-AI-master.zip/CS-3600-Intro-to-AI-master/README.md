# CS-3600-Intro-to-AI
Coursework for CS 3600: Introduction to Artificial Intelligence

A collection of Intro to AI assignments. Implementations cover a variety of search algorithms, reinforcement learning, neural nets, and bayesian inference.

## Disclaimer
This repository is here solely for archival/portfolio purposes. I don't make any promises on correctness for any classes other than the class I took.
